/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  output: 'standalone',
  // Configure image domains if needed
  images: {
    domains: [],
  },
  // Add any necessary rewrites or redirects
  async rewrites() {
    return [];
  },
};

module.exports = nextConfig;
