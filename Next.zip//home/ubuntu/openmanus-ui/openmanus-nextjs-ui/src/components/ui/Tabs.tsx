'use client'

import React from 'react'

interface TabsProps {
  children: React.ReactNode
  className?: string
}

export default function Tabs({ children, className = '' }: TabsProps) {
  return (
    <div className={`${className}`}>
      {children}
    </div>
  )
}

interface TabListProps {
  children: React.ReactNode
  className?: string
}

export function TabList({ children, className = '' }: TabListProps) {
  return (
    <div className={`flex border-b border-gray-200 dark:border-gray-700 ${className}`}>
      {children}
    </div>
  )
}

interface TabProps {
  children: React.ReactNode
  isActive?: boolean
  onClick?: () => void
  className?: string
}

export function Tab({ children, isActive = false, onClick, className = '' }: TabProps) {
  return (
    <button
      className={`
        py-2 px-4 text-sm font-medium border-b-2 -mb-px
        ${isActive 
          ? 'border-purple-500 text-purple-600 dark:text-purple-400' 
          : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:border-gray-600'
        }
        focus:outline-none
        ${className}
      `}
      onClick={onClick}
    >
      {children}
    </button>
  )
}

interface TabPanelProps {
  children: React.ReactNode
  className?: string
}

export function TabPanel({ children, className = '' }: TabPanelProps) {
  return (
    <div className={`py-4 ${className}`}>
      {children}
    </div>
  )
}
