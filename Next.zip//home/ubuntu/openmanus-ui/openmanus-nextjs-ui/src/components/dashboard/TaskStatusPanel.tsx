'use client'

import React from 'react'
import { useOpenManus } from '@/lib/api/OpenManusProvider'
import Card, { CardHeader, CardBody } from '@/components/ui/Card'
import Badge from '@/components/ui/Badge'
import { TaskStatus } from '@/lib/api/openManus'

export default function TaskStatusPanel() {
  const { activeTasks } = useOpenManus()
  
  return (
    <Card className="w-full">
      <CardHeader className="flex justify-between items-center">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Active Tasks</h2>
        <Badge variant="info">{activeTasks.length} Active</Badge>
      </CardHeader>
      <CardBody className="p-0">
        {activeTasks.length === 0 ? (
          <div className="p-6 text-center text-gray-500 dark:text-gray-400">
            No active tasks
          </div>
        ) : (
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {activeTasks.map((task) => (
              <TaskItem key={task.id} task={task} />
            ))}
          </div>
        )}
      </CardBody>
    </Card>
  )
}

interface TaskItemProps {
  task: TaskStatus
}

function TaskItem({ task }: TaskItemProps) {
  // Format the date
  const formattedDate = new Date(task.created_at).toLocaleString()
  
  // Determine status badge variant
  const statusVariant = {
    pending: 'info',
    running: 'warning',
    completed: 'success',
    failed: 'error'
  }[task.status] as 'info' | 'warning' | 'success' | 'error'
  
  return (
    <div className="p-4 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors">
      <div className="flex justify-between items-start mb-2">
        <div className="font-medium text-gray-900 dark:text-white truncate">
          Task ID: {task.id}
        </div>
        <Badge variant={statusVariant}>
          {task.status.charAt(0).toUpperCase() + task.status.slice(1)}
        </Badge>
      </div>
      <div className="text-sm text-gray-500 dark:text-gray-400">
        Created: {formattedDate}
      </div>
      {task.error && (
        <div className="mt-2 text-sm text-red-600 dark:text-red-400">
          Error: {task.error}
        </div>
      )}
    </div>
  )
}
