'use client'

import React, { useState, useRef, useEffect } from 'react'
import { useOpenManus } from '@/lib/api/OpenManusProvider'
import Card, { CardHeader, CardBody } from '@/components/ui/Card'
import Button from '@/components/ui/Button'
import ChatMessage from '@/components/ui/ChatMessage'
import CodeBlock from '@/components/ui/CodeBlock'
import { useToast } from '@/components/ui/Notification'

interface Message {
  id: string
  content: string
  sender: 'user' | 'assistant'
  timestamp: string
  type?: 'text' | 'code' | 'json'
  language?: string
}

export default function ChatInterface() {
  const { api, isConnected } = useOpenManus()
  const { addToast } = useToast()
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])
  
  const handleSendMessage = async () => {
    if (!api || !isConnected || !input.trim() || isProcessing) return
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: input.trim(),
      sender: 'user',
      timestamp: new Date().toISOString(),
      type: 'text'
    }
    
    setMessages(prev => [...prev, userMessage])
    setInput('')
    setIsProcessing(true)
    
    try {
      // Execute task with OpenManus API
      const taskId = await api.executeTask({
        prompt: userMessage.content
      })
      
      // In a real implementation, we would listen for task completion
      // For now, we'll simulate a response after a delay
      setTimeout(() => {
        const assistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: `This is a simulated response to your message. In a real implementation, this would be the actual response from OpenManus for task ID: ${taskId}`,
          sender: 'assistant',
          timestamp: new Date().toISOString(),
          type: 'text'
        }
        
        setMessages(prev => [...prev, assistantMessage])
        setIsProcessing(false)
      }, 2000)
      
    } catch (error) {
      console.error('Error sending message:', error)
      addToast({
        type: 'error',
        title: 'Failed to send message',
        message: error instanceof Error ? error.message : 'Unknown error occurred',
      })
      setIsProcessing(false)
    }
  }
  
  // Detect code blocks in message content
  const renderMessageContent = (message: Message) => {
    if (message.type === 'code' && message.language) {
      return <CodeBlock code={message.content} language={message.language} />
    } else if (message.type === 'json') {
      return <CodeBlock code={message.content} language="json" />
    } else {
      return message.content
    }
  }
  
  return (
    <Card className="w-full h-full flex flex-col">
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Chat</h2>
      </CardHeader>
      <CardBody className="flex-1 flex flex-col">
        <div className="flex-1 overflow-y-auto mb-4">
          {messages.length === 0 ? (
            <div className="text-center text-gray-500 dark:text-gray-400 py-8">
              No messages yet. Start a conversation!
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map(message => (
                <ChatMessage
                  key={message.id}
                  content={renderMessageContent(message)}
                  sender={message.sender}
                  timestamp={new Date(message.timestamp).toLocaleTimeString()}
                />
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
          <div className="flex space-x-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message here..."
              className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500 dark:bg-gray-800 dark:text-white min-h-[80px]"
              disabled={!isConnected || isProcessing}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault()
                  handleSendMessage()
                }
              }}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!isConnected || !input.trim() || isProcessing}
              isLoading={isProcessing}
              className="self-end"
            >
              Send
            </Button>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
            Press Shift+Enter for a new line. Enter to send.
          </p>
        </div>
      </CardBody>
    </Card>
  )
}
