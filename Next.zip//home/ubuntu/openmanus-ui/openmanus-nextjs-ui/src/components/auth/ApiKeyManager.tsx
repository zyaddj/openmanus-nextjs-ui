'use client'

import { useState, useEffect } from 'react'
import { createBrowserClient } from '@/lib/supabase'

interface ApiKey {
  id: string
  name: string
  key: string
  created_at: string
  last_used?: string
}

export default function ApiKeyManager() {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([])
  const [newKeyName, setNewKeyName] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [newlyCreatedKey, setNewlyCreatedKey] = useState<string | null>(null)
  
  const supabase = createBrowserClient()
  
  // Fetch API keys on component mount
  useEffect(() => {
    fetchApiKeys()
  }, [])
  
  const fetchApiKeys = async () => {
    setLoading(true)
    try {
      const { data: user } = await supabase.auth.getUser()
      
      if (!user.user) {
        throw new Error('Not authenticated')
      }
      
      const { data, error } = await supabase
        .from('api_keys')
        .select('*')
        .eq('user_id', user.user.id)
        .order('created_at', { ascending: false })
      
      if (error) throw error
      
      setApiKeys(data || [])
    } catch (err: any) {
      setError(err.message || 'Failed to fetch API keys')
    } finally {
      setLoading(false)
    }
  }
  
  const createApiKey = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(null)
    setNewlyCreatedKey(null)
    
    try {
      const { data: user } = await supabase.auth.getUser()
      
      if (!user.user) {
        throw new Error('Not authenticated')
      }
      
      // Generate a random API key
      const key = `om_${Math.random().toString(36).substring(2, 15)}${Math.random().toString(36).substring(2, 15)}`
      
      // Insert the new API key
      const { data, error } = await supabase
        .from('api_keys')
        .insert([
          {
            user_id: user.user.id,
            name: newKeyName,
            key: key,
          }
        ])
        .select()
      
      if (error) throw error
      
      setSuccess('API key created successfully')
      setNewKeyName('')
      setNewlyCreatedKey(key)
      fetchApiKeys()
    } catch (err: any) {
      setError(err.message || 'Failed to create API key')
    } finally {
      setLoading(false)
    }
  }
  
  const deleteApiKey = async (id: string) => {
    setLoading(true)
    setError(null)
    setSuccess(null)
    
    try {
      const { error } = await supabase
        .from('api_keys')
        .delete()
        .eq('id', id)
      
      if (error) throw error
      
      setSuccess('API key deleted successfully')
      fetchApiKeys()
    } catch (err: any) {
      setError(err.message || 'Failed to delete API key')
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="w-full bg-white dark:bg-gray-900 rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-white">API Key Management</h2>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
          {error}
        </div>
      )}
      
      {success && (
        <div className="mb-4 p-3 bg-green-100 border border-green-400 text-green-700 rounded">
          {success}
        </div>
      )}
      
      {newlyCreatedKey && (
        <div className="mb-6 p-4 bg-yellow-50 border border-yellow-400 rounded">
          <p className="font-medium text-yellow-800 mb-2">Your new API key (copy it now, you won't see it again):</p>
          <div className="flex">
            <code className="bg-gray-100 p-2 rounded flex-grow font-mono text-sm break-all">
              {newlyCreatedKey}
            </code>
            <button
              onClick={() => {
                navigator.clipboard.writeText(newlyCreatedKey);
                setSuccess('API key copied to clipboard');
              }}
              className="ml-2 px-3 py-1 bg-gray-200 hover:bg-gray-300 rounded text-gray-700"
              title="Copy to clipboard"
            >
              Copy
            </button>
          </div>
        </div>
      )}
      
      <form onSubmit={createApiKey} className="mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-grow">
            <label htmlFor="keyName" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              API Key Name
            </label>
            <input
              id="keyName"
              type="text"
              value={newKeyName}
              onChange={(e) => setNewKeyName(e.target.value)}
              placeholder="e.g., Development, Production"
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500 dark:bg-gray-800 dark:text-white"
              required
            />
          </div>
          <div className="self-end">
            <button
              type="submit"
              disabled={loading || !newKeyName}
              className="w-full md:w-auto py-2 px-4 border border-transparent rounded-md shadow-sm text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Creating...' : 'Create API Key'}
            </button>
          </div>
        </div>
      </form>
      
      <h3 className="text-xl font-semibold mb-4 text-gray-800 dark:text-white">Your API Keys</h3>
      
      {apiKeys.length === 0 ? (
        <p className="text-gray-500 dark:text-gray-400">You don't have any API keys yet.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-800">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Name
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Created
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Last Used
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
              {apiKeys.map((key) => (
                <tr key={key.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                    {key.name}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {new Date(key.created_at).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-300">
                    {key.last_used ? new Date(key.last_used).toLocaleDateString() : 'Never'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => deleteApiKey(key.id)}
                      className="text-red-600 hover:text-red-900 dark:text-red-400 dark:hover:text-red-300"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
