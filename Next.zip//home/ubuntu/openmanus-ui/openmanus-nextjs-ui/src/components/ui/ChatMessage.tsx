'use client'

import React from 'react'

interface ChatMessageProps {
  content: string
  sender: 'user' | 'assistant'
  timestamp?: string
  className?: string
}

export default function ChatMessage({
  content,
  sender,
  timestamp,
  className = '',
}: ChatMessageProps) {
  return (
    <div className={`flex ${sender === 'user' ? 'justify-end' : 'justify-start'} mb-4 ${className}`}>
      <div className={`
        max-w-3xl rounded-lg px-4 py-2
        ${sender === 'user' 
          ? 'bg-purple-600 text-white' 
          : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200'
        }
      `}>
        <div className="whitespace-pre-wrap">{content}</div>
        {timestamp && (
          <div className={`text-xs mt-1 ${sender === 'user' ? 'text-purple-200' : 'text-gray-500 dark:text-gray-400'}`}>
            {timestamp}
          </div>
        )}
      </div>
    </div>
  )
}
