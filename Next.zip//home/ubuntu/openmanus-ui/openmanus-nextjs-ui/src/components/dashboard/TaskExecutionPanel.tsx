'use client'

import React, { useState } from 'react'
import { useOpenManus } from '@/lib/api/OpenManusProvider'
import Card, { CardHeader, CardBody } from '@/components/ui/Card'
import Button from '@/components/ui/Button'
import Input from '@/components/ui/Input'
import { Dropdown, DropdownItem } from '@/components/ui/Dropdown'
import { useToast } from '@/components/ui/Notification'

export default function TaskExecutionPanel() {
  const { api, isConnected } = useOpenManus()
  const { addToast } = useToast()
  const [prompt, setPrompt] = useState('')
  const [isExecuting, setIsExecuting] = useState(false)
  
  const handleExecuteTask = async () => {
    if (!api || !isConnected || !prompt.trim()) return
    
    setIsExecuting(true)
    try {
      const taskId = await api.executeTask({
        prompt: prompt.trim()
      })
      
      addToast({
        type: 'success',
        title: 'Task started',
        message: `Task ID: ${taskId}`,
      })
      
      // Clear the prompt after successful execution
      setPrompt('')
    } catch (error) {
      console.error('Error executing task:', error)
      addToast({
        type: 'error',
        title: 'Failed to execute task',
        message: error instanceof Error ? error.message : 'Unknown error occurred',
      })
    } finally {
      setIsExecuting(false)
    }
  }
  
  return (
    <Card className="w-full">
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Execute Task</h2>
      </CardHeader>
      <CardBody>
        <div className="space-y-4">
          <div>
            <label htmlFor="prompt" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Prompt
            </label>
            <textarea
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Enter your task prompt here..."
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-700 rounded-md shadow-sm focus:outline-none focus:ring-purple-500 focus:border-purple-500 dark:bg-gray-800 dark:text-white min-h-[120px]"
              disabled={!isConnected || isExecuting}
            />
          </div>
          
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className="text-sm text-gray-600 dark:text-gray-400">
                {isConnected ? 'Connected to OpenManus' : 'Not connected'}
              </span>
            </div>
            
            <div className="flex space-x-2">
              <Button
                variant="outline"
                onClick={() => setPrompt('')}
                disabled={!prompt || isExecuting}
              >
                Clear
              </Button>
              
              <Button
                onClick={handleExecuteTask}
                disabled={!isConnected || !prompt.trim() || isExecuting}
                isLoading={isExecuting}
              >
                Execute Task
              </Button>
            </div>
          </div>
        </div>
      </CardBody>
    </Card>
  )
}
