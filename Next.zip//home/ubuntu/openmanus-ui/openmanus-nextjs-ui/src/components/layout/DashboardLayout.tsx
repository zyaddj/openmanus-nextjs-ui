'use client'

import React from 'react'

interface LayoutProps {
  children: React.ReactNode
}

export default function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen bg-light-background dark:bg-dark-background">
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          {children}
        </main>
      </div>
    </div>
  )
}

interface SidebarProps {
  className?: string
}

function Sidebar({ className = '' }: SidebarProps) {
  return (
    <aside className={`w-64 min-h-screen bg-white dark:bg-dark-surface border-r border-light-border dark:border-dark-border ${className}`}>
      <div className="p-4 border-b border-light-border dark:border-dark-border">
        <h1 className="text-xl font-bold text-purple-600 dark:text-purple-400">OpenManus</h1>
      </div>
      
      <nav className="p-4">
        <ul className="space-y-2">
          <SidebarItem href="/dashboard" icon={<HomeIcon />}>Dashboard</SidebarItem>
          <SidebarItem href="/chat" icon={<ChatIcon />}>Chat</SidebarItem>
          <SidebarItem href="/models" icon={<ModelIcon />}>Models</SidebarItem>
          <SidebarItem href="/settings" icon={<SettingsIcon />}>Settings</SidebarItem>
        </ul>
      </nav>
    </aside>
  )
}

interface SidebarItemProps {
  children: React.ReactNode
  href: string
  icon?: React.ReactNode
  className?: string
}

function SidebarItem({ children, href, icon, className = '' }: SidebarItemProps) {
  // In a real implementation, we would use usePathname() to check if the item is active
  const isActive = false
  
  return (
    <li>
      <a 
        href={href}
        className={`
          flex items-center px-4 py-2 rounded-md text-sm font-medium
          ${isActive 
            ? 'bg-purple-50 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300' 
            : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800'
          }
          ${className}
        `}
      >
        {icon && <span className="mr-3">{icon}</span>}
        {children}
      </a>
    </li>
  )
}

// Simple icon components
function HomeIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
      <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
    </svg>
  )
}

function ChatIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z" clipRule="evenodd" />
    </svg>
  )
}

function ModelIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
      <path d="M13 7H7v6h6V7z" />
      <path fillRule="evenodd" d="M7 2a1 1 0 012 0v1h2V2a1 1 0 112 0v1h2a2 2 0 012 2v2h1a1 1 0 110 2h-1v2h1a1 1 0 110 2h-1v2a2 2 0 01-2 2h-2v1a1 1 0 11-2 0v-1H9v1a1 1 0 11-2 0v-1H5a2 2 0 01-2-2v-2H2a1 1 0 110-2h1V9H2a1 1 0 010-2h1V5a2 2 0 012-2h2V2zM5 5h10v10H5V5z" clipRule="evenodd" />
    </svg>
  )
}

function SettingsIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
      <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
    </svg>
  )
}
