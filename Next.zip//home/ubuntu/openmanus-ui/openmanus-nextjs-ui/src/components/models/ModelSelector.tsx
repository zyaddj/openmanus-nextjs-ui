'use client'

import React from 'react'
import Card, { CardHeader, CardBody } from '@/components/ui/Card'
import { Tabs, TabList, Tab, TabPanel } from '@/components/ui/Tabs'
import Input from '@/components/ui/Input'
import Button from '@/components/ui/Button'
import { useOpenManus } from '@/lib/api/OpenManusProvider'

// Define model types and providers
const MODEL_PROVIDERS = {
  openai: {
    name: 'OpenAI',
    models: [
      { id: 'gpt-4o', name: 'GPT-4o' },
      { id: 'gpt-4-turbo', name: 'GPT-4 Turbo' },
      { id: 'gpt-4', name: 'GPT-4' },
      { id: 'gpt-3.5-turbo', name: 'GPT-3.5 Turbo' }
    ]
  },
  anthropic: {
    name: 'Anthropic',
    models: [
      { id: 'claude-3-opus-20240229', name: 'Claude 3 Opus' },
      { id: 'claude-3-sonnet-20240229', name: 'Claude 3 Sonnet' },
      { id: 'claude-3-haiku-20240307', name: 'Claude 3 Haiku' },
      { id: 'claude-2.1', name: 'Claude 2.1' }
    ]
  },
  google: {
    name: 'Google',
    models: [
      { id: 'gemini-1.5-pro', name: 'Gemini 1.5 Pro' },
      { id: 'gemini-1.5-flash', name: 'Gemini 1.5 Flash' },
      { id: 'gemini-1.0-pro', name: 'Gemini 1.0 Pro' }
    ]
  },
  local: {
    name: 'Local Models',
    models: [
      { id: 'llama-3-70b', name: 'Llama 3 (70B)' },
      { id: 'llama-3-8b', name: 'Llama 3 (8B)' },
      { id: 'mistral-7b', name: 'Mistral (7B)' }
    ]
  }
}

export default function ModelSelector() {
  const { api, isConnected } = useOpenManus()
  const [activeProvider, setActiveProvider] = React.useState('openai')
  const [selectedModel, setSelectedModel] = React.useState('gpt-4o')
  const [apiKey, setApiKey] = React.useState('')
  const [baseUrl, setBaseUrl] = React.useState('')
  const [temperature, setTemperature] = React.useState('0')
  const [maxTokens, setMaxTokens] = React.useState('4096')
  const [isSaving, setIsSaving] = React.useState(false)
  
  // Handle saving model configuration
  const handleSaveConfig = async () => {
    if (!api || !isConnected) return
    
    setIsSaving(true)
    try {
      await api.updateConfig({
        llm: {
          model: selectedModel,
          base_url: baseUrl,
          api_key: apiKey,
          max_tokens: parseInt(maxTokens),
          temperature: parseFloat(temperature)
        }
      })
      
      // Show success notification (in a real implementation)
      console.log('Model configuration saved successfully')
    } catch (error) {
      // Show error notification (in a real implementation)
      console.error('Failed to save model configuration:', error)
    } finally {
      setIsSaving(false)
    }
  }
  
  // Handle model selection
  const handleModelSelect = (modelId: string) => {
    setSelectedModel(modelId)
  }
  
  return (
    <Card className="w-full">
      <CardHeader>
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Model Selection</h2>
      </CardHeader>
      <CardBody>
        <Tabs>
          <TabList>
            {Object.entries(MODEL_PROVIDERS).map(([providerId, provider]) => (
              <Tab 
                key={providerId}
                isActive={activeProvider === providerId}
                onClick={() => setActiveProvider(providerId)}
              >
                {provider.name}
              </Tab>
            ))}
          </TabList>
          
          {Object.entries(MODEL_PROVIDERS).map(([providerId, provider]) => (
            <TabPanel key={providerId} className={activeProvider !== providerId ? 'hidden' : ''}>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 mt-4">
                {provider.models.map(model => (
                  <div 
                    key={model.id}
                    className={`
                      p-4 rounded-lg border cursor-pointer transition-colors
                      ${selectedModel === model.id 
                        ? 'border-purple-500 bg-purple-50 dark:bg-purple-900/30' 
                        : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800'
                      }
                    `}
                    onClick={() => handleModelSelect(model.id)}
                  >
                    <div className="font-medium text-gray-900 dark:text-white">{model.name}</div>
                    <div className="text-sm text-gray-500 dark:text-gray-400">{model.id}</div>
                  </div>
                ))}
              </div>
            </TabPanel>
          ))}
        </Tabs>
        
        <div className="mt-8 border-t border-gray-200 dark:border-gray-700 pt-6">
          <h3 className="text-md font-medium text-gray-900 dark:text-white mb-4">Model Configuration</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <Input
              label="API Key"
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="Enter API key for selected model"
            />
            <Input
              label="Base URL (Optional)"
              value={baseUrl}
              onChange={(e) => setBaseUrl(e.target.value)}
              placeholder="Custom API endpoint URL"
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Temperature: {temperature}
              </label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={temperature}
                onChange={(e) => setTemperature(e.target.value)}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
              />
              <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400 mt-1">
                <span>0 (Deterministic)</span>
                <span>1 (Creative)</span>
              </div>
            </div>
            
            <Input
              label="Max Tokens"
              type="number"
              value={maxTokens}
              onChange={(e) => setMaxTokens(e.target.value)}
              min="1"
              max="32000"
            />
          </div>
          
          <div className="flex justify-end">
            <Button
              onClick={handleSaveConfig}
              disabled={!isConnected || isSaving}
              isLoading={isSaving}
            >
              Save Configuration
            </Button>
          </div>
        </div>
      </CardBody>
    </Card>
  )
}
