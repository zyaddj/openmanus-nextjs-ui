'use client'

import React, { useState, useEffect } from 'react'
import { useOpenManus } from '@/lib/api/OpenManusProvider'
import Card, { CardHeader, CardBody } from '@/components/ui/Card'
import CodeBlock from '@/components/ui/CodeBlock'
import Button from '@/components/ui/Button'
import { Tabs, TabList, Tab, TabPanel } from '@/components/ui/Tabs'

export default function LogsPanel() {
  const { activeTasks, taskLogs } = useOpenManus()
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null)
  
  // Auto-select the first task when tasks change
  useEffect(() => {
    if (activeTasks.length > 0 && !selectedTaskId) {
      setSelectedTaskId(activeTasks[0].id)
    } else if (activeTasks.length === 0) {
      setSelectedTaskId(null)
    } else if (selectedTaskId && !activeTasks.find(task => task.id === selectedTaskId)) {
      setSelectedTaskId(activeTasks[0].id)
    }
  }, [activeTasks, selectedTaskId])
  
  const selectedTaskLogs = selectedTaskId ? taskLogs[selectedTaskId] || [] : []
  
  return (
    <Card className="w-full">
      <CardHeader className="flex justify-between items-center">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Task Logs</h2>
        {activeTasks.length > 0 && (
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                // In a real implementation, this would copy logs to clipboard
                if (selectedTaskId && selectedTaskLogs.length > 0) {
                  navigator.clipboard.writeText(selectedTaskLogs.join('\n'))
                }
              }}
            >
              Copy Logs
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                // In a real implementation, this would download logs as a file
              }}
            >
              Download
            </Button>
          </div>
        )}
      </CardHeader>
      <CardBody>
        {activeTasks.length === 0 ? (
          <div className="text-center text-gray-500 dark:text-gray-400 py-8">
            No active tasks to display logs
          </div>
        ) : (
          <>
            <TabList className="mb-4">
              {activeTasks.map(task => (
                <Tab 
                  key={task.id} 
                  isActive={selectedTaskId === task.id}
                  onClick={() => setSelectedTaskId(task.id)}
                >
                  Task {task.id.substring(0, 8)}
                </Tab>
              ))}
            </TabList>
            
            <div className="bg-gray-50 dark:bg-gray-900 rounded-md p-1 max-h-96 overflow-y-auto">
              {selectedTaskLogs.length === 0 ? (
                <div className="text-center text-gray-500 dark:text-gray-400 py-8">
                  No logs available for this task
                </div>
              ) : (
                <pre className="text-sm text-gray-800 dark:text-gray-200 whitespace-pre-wrap p-3">
                  {selectedTaskLogs.join('\n')}
                </pre>
              )}
            </div>
          </>
        )}
      </CardBody>
    </Card>
  )
}
