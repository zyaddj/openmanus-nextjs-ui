'use client'

import React, { useState, useRef, useEffect } from 'react'

interface DropdownProps {
  trigger: React.ReactNode
  children: React.ReactNode
  align?: 'left' | 'right'
  width?: 'auto' | 'sm' | 'md' | 'lg' | 'full'
  className?: string
}

export default function Dropdown({
  trigger,
  children,
  align = 'left',
  width = 'md',
  className = '',
}: DropdownProps) {
  const [isOpen, setIsOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)
  
  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false)
      }
    }
    
    document.addEventListener('mousedown', handleClickOutside)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [])
  
  // Width classes
  const widthClasses = {
    auto: 'w-auto',
    sm: 'w-48',
    md: 'w-56',
    lg: 'w-64',
    full: 'w-full',
  }
  
  // Alignment classes
  const alignClasses = {
    left: 'left-0',
    right: 'right-0',
  }
  
  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <div onClick={() => setIsOpen(!isOpen)}>
        {trigger}
      </div>
      
      {isOpen && (
        <div 
          className={`
            absolute z-10 mt-2 origin-top-right rounded-md shadow-lg 
            bg-white dark:bg-gray-800 
            ring-1 ring-black ring-opacity-5 
            ${alignClasses[align]} 
            ${widthClasses[width]}
            ${className}
          `}
        >
          <div 
            className="py-1 rounded-md bg-white dark:bg-gray-800 shadow-xs"
            role="menu" 
            aria-orientation="vertical" 
            aria-labelledby="options-menu"
          >
            {children}
          </div>
        </div>
      )}
    </div>
  )
}

interface DropdownItemProps {
  children: React.ReactNode
  onClick?: () => void
  icon?: React.ReactNode
  className?: string
  disabled?: boolean
}

export function DropdownItem({
  children,
  onClick,
  icon,
  className = '',
  disabled = false,
}: DropdownItemProps) {
  return (
    <button
      className={`
        w-full text-left px-4 py-2 text-sm leading-5 
        ${disabled 
          ? 'text-gray-400 dark:text-gray-500 cursor-not-allowed' 
          : 'text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:bg-gray-100 dark:focus:bg-gray-700'
        }
        flex items-center
        ${className}
      `}
      role="menuitem"
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
    >
      {icon && <span className="mr-2">{icon}</span>}
      {children}
    </button>
  )
}

export function DropdownDivider() {
  return <div className="border-t border-gray-200 dark:border-gray-700 my-1"></div>
}
