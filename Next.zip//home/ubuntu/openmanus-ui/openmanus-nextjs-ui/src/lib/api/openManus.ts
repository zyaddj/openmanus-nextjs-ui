import axios from 'axios';

// Define types for OpenManus API responses and requests
export interface OpenManusConfig {
  llm: {
    model: string;
    base_url: string;
    api_key: string;
    max_tokens: number;
    temperature: number;
    vision?: {
      model: string;
      base_url: string;
      api_key: string;
      max_tokens: number;
      temperature: number;
    };
  };
  browser?: {
    headless: boolean;
    disable_security: boolean;
    extra_chromium_args?: string[];
    chrome_instance_path?: string;
    wss_url?: string;
    cdp_url?: string;
    proxy?: {
      server: string;
      username?: string;
      password?: string;
    };
  };
  search?: {
    engine: 'Google' | 'Baidu' | 'DuckDuckGo';
    fallback_engines: ('Google' | 'Baidu' | 'DuckDuckGo')[];
    retry_delay: number;
    max_retries: number;
  };
  sandbox?: {
    use_sandbox: boolean;
    image: string;
    work_dir: string;
    memory_limit: string;
    cpu_limit: number;
    timeout: number;
    network_enabled: boolean;
  };
}

export interface ToolExecutionRequest {
  tool_name: string;
  parameters: Record<string, any>;
}

export interface ToolExecutionResponse {
  success: boolean;
  result?: any;
  error?: string;
}

export interface TaskExecutionRequest {
  prompt: string;
  model?: string;
  temperature?: number;
  max_tokens?: number;
}

export interface TaskStatus {
  id: string;
  status: 'pending' | 'running' | 'completed' | 'failed';
  created_at: string;
  updated_at: string;
  result?: any;
  error?: string;
  logs?: string[];
}

// OpenManus API client
export class OpenManusAPI {
  private baseUrl: string;
  private apiKey: string;

  constructor(baseUrl: string, apiKey: string) {
    this.baseUrl = baseUrl;
    this.apiKey = apiKey;
  }

  private getHeaders() {
    return {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.apiKey}`
    };
  }

  // Get server configuration
  async getConfig(): Promise<OpenManusConfig> {
    try {
      const response = await axios.get(`${this.baseUrl}/config`, {
        headers: this.getHeaders()
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching OpenManus config:', error);
      throw error;
    }
  }

  // Update server configuration
  async updateConfig(config: Partial<OpenManusConfig>): Promise<OpenManusConfig> {
    try {
      const response = await axios.patch(`${this.baseUrl}/config`, config, {
        headers: this.getHeaders()
      });
      return response.data;
    } catch (error) {
      console.error('Error updating OpenManus config:', error);
      throw error;
    }
  }

  // Execute a specific tool
  async executeTool(request: ToolExecutionRequest): Promise<ToolExecutionResponse> {
    try {
      const response = await axios.post(`${this.baseUrl}/tools/execute`, request, {
        headers: this.getHeaders()
      });
      return response.data;
    } catch (error) {
      console.error(`Error executing tool ${request.tool_name}:`, error);
      throw error;
    }
  }

  // Get available tools
  async getTools(): Promise<string[]> {
    try {
      const response = await axios.get(`${this.baseUrl}/tools`, {
        headers: this.getHeaders()
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching available tools:', error);
      throw error;
    }
  }

  // Execute a task (prompt)
  async executeTask(request: TaskExecutionRequest): Promise<string> {
    try {
      const response = await axios.post(`${this.baseUrl}/tasks`, request, {
        headers: this.getHeaders()
      });
      return response.data.task_id;
    } catch (error) {
      console.error('Error executing task:', error);
      throw error;
    }
  }

  // Get task status
  async getTaskStatus(taskId: string): Promise<TaskStatus> {
    try {
      const response = await axios.get(`${this.baseUrl}/tasks/${taskId}`, {
        headers: this.getHeaders()
      });
      return response.data;
    } catch (error) {
      console.error(`Error fetching task status for ${taskId}:`, error);
      throw error;
    }
  }

  // Get task logs
  async getTaskLogs(taskId: string): Promise<string[]> {
    try {
      const response = await axios.get(`${this.baseUrl}/tasks/${taskId}/logs`, {
        headers: this.getHeaders()
      });
      return response.data.logs;
    } catch (error) {
      console.error(`Error fetching logs for task ${taskId}:`, error);
      throw error;
    }
  }

  // Cancel a running task
  async cancelTask(taskId: string): Promise<boolean> {
    try {
      const response = await axios.delete(`${this.baseUrl}/tasks/${taskId}`, {
        headers: this.getHeaders()
      });
      return response.data.success;
    } catch (error) {
      console.error(`Error canceling task ${taskId}:`, error);
      throw error;
    }
  }

  // Get server status
  async getStatus(): Promise<{status: string, version: string}> {
    try {
      const response = await axios.get(`${this.baseUrl}/status`, {
        headers: this.getHeaders()
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching server status:', error);
      throw error;
    }
  }
}
