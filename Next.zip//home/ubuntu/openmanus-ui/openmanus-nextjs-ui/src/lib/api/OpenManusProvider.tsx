'use client'

import { createContext, useContext, useEffect, useState } from 'react'
import { io, Socket } from 'socket.io-client'
import { OpenManusAPI, TaskStatus } from './openManus'

interface OpenManusContextType {
  api: OpenManusAPI | null
  socket: Socket | null
  isConnected: boolean
  activeTasks: TaskStatus[]
  taskLogs: Record<string, string[]>
  connectToServer: (baseUrl: string, apiKey: string) => void
  disconnectFromServer: () => void
}

const OpenManusContext = createContext<OpenManusContextType>({
  api: null,
  socket: null,
  isConnected: false,
  activeTasks: [],
  taskLogs: {},
  connectToServer: () => {},
  disconnectFromServer: () => {},
})

export function OpenManusProvider({ children }: { children: React.ReactNode }) {
  const [api, setApi] = useState<OpenManusAPI | null>(null)
  const [socket, setSocket] = useState<Socket | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [activeTasks, setActiveTasks] = useState<TaskStatus[]>([])
  const [taskLogs, setTaskLogs] = useState<Record<string, string[]>>({})
  
  // Connect to OpenManus server
  const connectToServer = (baseUrl: string, apiKey: string) => {
    // Create API client
    const apiClient = new OpenManusAPI(baseUrl, apiKey)
    setApi(apiClient)
    
    // Create socket connection for real-time updates
    const socketClient = io(baseUrl, {
      auth: {
        token: apiKey
      }
    })
    
    socketClient.on('connect', () => {
      console.log('Connected to OpenManus server')
      setIsConnected(true)
      
      // Fetch active tasks on connection
      fetchActiveTasks(apiClient)
    })
    
    socketClient.on('disconnect', () => {
      console.log('Disconnected from OpenManus server')
      setIsConnected(false)
    })
    
    // Listen for task updates
    socketClient.on('task:update', (task: TaskStatus) => {
      setActiveTasks(prev => {
        const index = prev.findIndex(t => t.id === task.id)
        if (index >= 0) {
          const updated = [...prev]
          updated[index] = task
          return updated
        } else {
          return [...prev, task]
        }
      })
    })
    
    // Listen for task logs
    socketClient.on('task:log', ({ taskId, log }: { taskId: string, log: string }) => {
      setTaskLogs(prev => {
        const taskLogs = prev[taskId] || []
        return {
          ...prev,
          [taskId]: [...taskLogs, log]
        }
      })
    })
    
    // Listen for task completion
    socketClient.on('task:complete', (task: TaskStatus) => {
      setActiveTasks(prev => {
        const index = prev.findIndex(t => t.id === task.id)
        if (index >= 0) {
          const updated = [...prev]
          updated[index] = task
          return updated
        } else {
          return prev
        }
      })
    })
    
    setSocket(socketClient)
  }
  
  // Disconnect from OpenManus server
  const disconnectFromServer = () => {
    if (socket) {
      socket.disconnect()
      setSocket(null)
    }
    setApi(null)
    setIsConnected(false)
    setActiveTasks([])
    setTaskLogs({})
  }
  
  // Fetch active tasks from the server
  const fetchActiveTasks = async (apiClient: OpenManusAPI) => {
    try {
      // In a real implementation, we would have an endpoint to get all active tasks
      // For now, we'll just initialize with an empty array
      setActiveTasks([])
    } catch (error) {
      console.error('Error fetching active tasks:', error)
    }
  }
  
  // Clean up on unmount
  useEffect(() => {
    return () => {
      disconnectFromServer()
    }
  }, [])
  
  return (
    <OpenManusContext.Provider
      value={{
        api,
        socket,
        isConnected,
        activeTasks,
        taskLogs,
        connectToServer,
        disconnectFromServer,
      }}
    >
      {children}
    </OpenManusContext.Provider>
  )
}

export const useOpenManus = () => useContext(OpenManusContext)
