'use client'

import React from 'react'
import { useOpenManus } from '@/lib/api/OpenManusProvider'
import Card, { CardHeader, CardBody } from '@/components/ui/Card'
import { Tabs, TabList, Tab, TabPanel } from '@/components/ui/Tabs'
import Input from '@/components/ui/Input'
import Button from '@/components/ui/Button'
import ThemeToggle from '@/components/ui/ThemeToggle'

export default function SettingsPage() {
  const { api, isConnected } = useOpenManus()
  const [activeTab, setActiveTab] = React.useState('general')
  const [isDarkMode, setIsDarkMode] = React.useState(true)
  
  // General settings
  const [username, setUsername] = React.useState('')
  const [email, setEmail] = React.useState('')
  
  // Notification settings
  const [emailNotifications, setEmailNotifications] = React.useState(false)
  const [desktopNotifications, setDesktopNotifications] = React.useState(true)
  
  // Advanced settings
  const [debugMode, setDebugMode] = React.useState(false)
  const [autoSave, setAutoSave] = React.useState(true)
  
  const handleSaveSettings = () => {
    // In a real implementation, this would save settings to the backend
    console.log('Saving settings...')
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Settings</h1>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600 dark:text-gray-400">Theme</span>
            <ThemeToggle />
          </div>
          <a href="/dashboard" className="text-purple-600 hover:text-purple-700 dark:text-purple-400 dark:hover:text-purple-300">
            Dashboard
          </a>
        </div>
      </div>
      
      <Card className="w-full">
        <CardHeader>
          <Tabs>
            <TabList>
              <Tab 
                isActive={activeTab === 'general'}
                onClick={() => setActiveTab('general')}
              >
                General
              </Tab>
              <Tab 
                isActive={activeTab === 'notifications'}
                onClick={() => setActiveTab('notifications')}
              >
                Notifications
              </Tab>
              <Tab 
                isActive={activeTab === 'advanced'}
                onClick={() => setActiveTab('advanced')}
              >
                Advanced
              </Tab>
            </TabList>
          </Tabs>
        </CardHeader>
        <CardBody>
          <div className={activeTab === 'general' ? '' : 'hidden'}>
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Input
                  label="Username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Your username"
                />
                <Input
                  label="Email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address"
                />
              </div>
              
              <div>
                <h3 className="text-md font-medium text-gray-900 dark:text-white mb-4">Appearance</h3>
                <div className="flex items-center space-x-4">
                  <label className="inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={isDarkMode}
                      onChange={() => setIsDarkMode(!isDarkMode)}
                    />
                    <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 dark:peer-focus:ring-purple-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-purple-600"></div>
                    <span className="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300">Dark Mode</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
          
          <div className={activeTab === 'notifications' ? '' : 'hidden'}>
            <div className="space-y-6">
              <div>
                <h3 className="text-md font-medium text-gray-900 dark:text-white mb-4">Notification Preferences</h3>
                <div className="space-y-4">
                  <label className="inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={emailNotifications}
                      onChange={() => setEmailNotifications(!emailNotifications)}
                    />
                    <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 dark:peer-focus:ring-purple-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-purple-600"></div>
                    <span className="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300">Email Notifications</span>
                  </label>
                  
                  <label className="inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={desktopNotifications}
                      onChange={() => setDesktopNotifications(!desktopNotifications)}
                    />
                    <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 dark:peer-focus:ring-purple-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-purple-600"></div>
                    <span className="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300">Desktop Notifications</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
          
          <div className={activeTab === 'advanced' ? '' : 'hidden'}>
            <div className="space-y-6">
              <div>
                <h3 className="text-md font-medium text-gray-900 dark:text-white mb-4">Advanced Settings</h3>
                <div className="space-y-4">
                  <label className="inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={debugMode}
                      onChange={() => setDebugMode(!debugMode)}
                    />
                    <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 dark:peer-focus:ring-purple-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-purple-600"></div>
                    <span className="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300">Debug Mode</span>
                  </label>
                  
                  <label className="inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={autoSave}
                      onChange={() => setAutoSave(!autoSave)}
                    />
                    <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-purple-300 dark:peer-focus:ring-purple-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-purple-600"></div>
                    <span className="ms-3 text-sm font-medium text-gray-900 dark:text-gray-300">Auto-save</span>
                  </label>
                </div>
              </div>
              
              <div>
                <h3 className="text-md font-medium text-gray-900 dark:text-white mb-4">Danger Zone</h3>
                <Button variant="danger">Reset All Settings</Button>
              </div>
            </div>
          </div>
          
          <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700 flex justify-end">
            <Button onClick={handleSaveSettings}>
              Save Settings
            </Button>
          </div>
        </CardBody>
      </Card>
    </div>
  )
}
