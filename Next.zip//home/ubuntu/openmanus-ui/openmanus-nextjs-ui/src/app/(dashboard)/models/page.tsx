'use client'

import React from 'react'
import { useOpenManus } from '@/lib/api/OpenManusProvider'
import ModelSelector from '@/components/models/ModelSelector'
import ChatInterface from '@/components/chat/ChatInterface'
import { ThemeProvider } from '@/components/ui/ThemeProvider'
import { ToastProvider } from '@/components/ui/Notification'

export default function ModelsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Model Configuration</h1>
        <div className="flex items-center space-x-4">
          <a href="/dashboard" className="text-purple-600 hover:text-purple-700 dark:text-purple-400 dark:hover:text-purple-300">
            Dashboard
          </a>
        </div>
      </div>
      
      <div className="mb-8">
        <ModelSelector />
      </div>
      
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Test Your Model</h2>
        <div className="h-[500px]">
          <ChatInterface />
        </div>
      </div>
    </div>
  )
}
