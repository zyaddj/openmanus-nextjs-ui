'use client'

import React from 'react'
import { useOpenManus } from '@/lib/api/OpenManusProvider'
import TaskStatusPanel from '@/components/dashboard/TaskStatusPanel'
import LogsPanel from '@/components/dashboard/LogsPanel'
import TaskExecutionPanel from '@/components/dashboard/TaskExecutionPanel'
import Card, { CardHeader, CardBody } from '@/components/ui/Card'
import Button from '@/components/ui/Button'
import Input from '@/components/ui/Input'
import ThemeToggle from '@/components/ui/ThemeToggle'

export default function Dashboard() {
  const { isConnected, connectToServer, disconnectFromServer } = useOpenManus()
  const [serverUrl, setServerUrl] = React.useState('http://localhost:8000')
  const [apiKey, setApiKey] = React.useState('')
  
  const handleConnect = () => {
    if (!serverUrl || !apiKey) return
    connectToServer(serverUrl, apiKey)
  }
  
  const handleDisconnect = () => {
    disconnectFromServer()
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">OpenManus Dashboard</h1>
        <div className="flex items-center space-x-4">
          <ThemeToggle />
          <a href="/settings" className="text-purple-600 hover:text-purple-700 dark:text-purple-400 dark:hover:text-purple-300">
            Settings
          </a>
        </div>
      </div>
      
      {!isConnected ? (
        <Card className="mb-8">
          <CardHeader>
            <h2 className="text-lg font-semibold text-gray-800 dark:text-white">Connect to OpenManus</h2>
          </CardHeader>
          <CardBody>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <Input
                label="Server URL"
                value={serverUrl}
                onChange={(e) => setServerUrl(e.target.value)}
                placeholder="http://localhost:8000"
              />
              <Input
                label="API Key"
                type="password"
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                placeholder="Enter your API key"
              />
            </div>
            <Button onClick={handleConnect} disabled={!serverUrl || !apiKey}>
              Connect
            </Button>
          </CardBody>
        </Card>
      ) : (
        <>
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 rounded-full bg-green-500"></div>
              <span className="text-sm text-gray-600 dark:text-gray-400">
                Connected to {serverUrl}
              </span>
            </div>
            <Button variant="outline" size="sm" onClick={handleDisconnect}>
              Disconnect
            </Button>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <div className="lg:col-span-2">
              <TaskExecutionPanel />
            </div>
            <div>
              <TaskStatusPanel />
            </div>
          </div>
          
          <LogsPanel />
        </>
      )}
    </div>
  )
}
