# OpenManus Next.js UI

A comprehensive and fully functional Next.js web interface for [OpenManus](https://github.com/mannaandpoem/OpenManus), featuring robust backend integration, dramatically enhanced aesthetics, and a modernized UI.

![OpenManus UI](https://placeholder-for-screenshot.com/openmanus-ui.png)

## Features

- **Robust Authentication**: User registration, login, and API key management via Supabase
- **Modern UI**: Sleek black & purple dark mode and clean white & purple light mode
- **Model Selection**: Support for multiple AI models (GPT-4, Claude, Gemini, local Llama models)
- **Interactive Chat**: Rich output formatting for text, code, and JSON
- **Real-time Updates**: Live task execution and monitoring
- **Comprehensive Settings**: Theme toggle, model configuration, and more

## Tech Stack

- **Frontend**: Next.js, React, TypeScript
- **Styling**: Tailwind CSS with custom theming
- **Authentication**: Supabase
- **Backend Integration**: OpenManus REST API
- **Deployment**: Vercel

## Getting Started

### Prerequisites

- Node.js 18.0.0 or higher
- npm or yarn
- Supabase account for authentication
- OpenManus backend running

### Installation

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/openmanus-nextjs-ui.git
   cd openmanus-nextjs-ui
   ```

2. Install dependencies:
   ```bash
   npm install
   # or
   yarn install
   ```

3. Set up environment variables:
   - Copy `.env.example` to `.env.local`
   - Fill in your Supabase and OpenManus backend details

4. Run the development server:
   ```bash
   npm run dev
   # or
   yarn dev
   ```

5. Open [http://localhost:3000](http://localhost:3000) in your browser to see the application.

## Deployment Guide

### Deploying to Vercel

1. **Create a Vercel Account**:
   - Sign up at [vercel.com](https://vercel.com) if you don't have an account.

2. **Install Vercel CLI** (optional):
   ```bash
   npm install -g vercel
   ```

3. **Set Up Environment Variables**:
   - In the Vercel dashboard, go to your project settings.
   - Add the following environment variables:
     - `NEXT_PUBLIC_SUPABASE_URL`: Your Supabase project URL
     - `NEXT_PUBLIC_SUPABASE_ANON_KEY`: Your Supabase anonymous key
     - `NEXT_PUBLIC_OPENMANUS_API_URL`: URL to your OpenManus backend API
     - `NEXT_PUBLIC_OPENMANUS_SOCKET_URL`: URL for WebSocket connections to OpenManus

4. **Deploy Using Vercel CLI**:
   ```bash
   vercel
   ```
   
   Or deploy directly from the Vercel dashboard by connecting your GitHub repository.

5. **Production Deployment**:
   ```bash
   vercel --prod
   ```

### Supabase Configuration

1. **Create a Supabase Project**:
   - Go to [supabase.com](https://supabase.com) and create a new project.

2. **Set Up Authentication**:
   - Enable Email/Password authentication in the Auth settings.
   - Configure any additional providers as needed.

3. **Create API Keys Table**:
   - Execute the following SQL in the Supabase SQL editor:
   ```sql
   CREATE TABLE api_keys (
     id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
     user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
     name TEXT NOT NULL,
     key TEXT NOT NULL UNIQUE,
     created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
     last_used TIMESTAMP WITH TIME ZONE
   );

   -- Create policy to allow users to see only their own API keys
   CREATE POLICY "Users can view their own API keys" 
     ON api_keys FOR SELECT 
     USING (auth.uid() = user_id);

   -- Create policy to allow users to insert their own API keys
   CREATE POLICY "Users can insert their own API keys" 
     ON api_keys FOR INSERT 
     WITH CHECK (auth.uid() = user_id);

   -- Create policy to allow users to delete their own API keys
   CREATE POLICY "Users can delete their own API keys" 
     ON api_keys FOR DELETE 
     USING (auth.uid() = user_id);
   ```

4. **Enable Row Level Security**:
   - Make sure RLS is enabled on the `api_keys` table.

### OpenManus Backend Integration

1. **Set Up OpenManus Backend**:
   - Follow the installation instructions in the [OpenManus repository](https://github.com/mannaandpoem/OpenManus).
   - Configure the backend to accept API requests from your frontend domain.

2. **API Configuration**:
   - Ensure your OpenManus backend is accessible from your deployed frontend.
   - Update the `NEXT_PUBLIC_OPENMANUS_API_URL` and `NEXT_PUBLIC_OPENMANUS_SOCKET_URL` environment variables with the correct URLs.

## Development Guide

### Project Structure

```
openmanus-nextjs-ui/
├── src/
│   ├── app/                  # Next.js App Router
│   │   ├── (auth)/           # Authentication routes
│   │   ├── (dashboard)/      # Dashboard routes
│   │   └── api/              # API routes
│   ├── components/           # React components
│   │   ├── auth/             # Authentication components
│   │   ├── chat/             # Chat interface components
│   │   ├── dashboard/        # Dashboard components
│   │   ├── layout/           # Layout components
│   │   ├── models/           # Model selection components
│   │   └── ui/               # UI components
│   └── lib/                  # Utility functions
│       └── api/              # API client
├── public/                   # Static files
├── .env.example              # Example environment variables
├── next.config.js            # Next.js configuration
├── package.json              # Dependencies
├── tailwind.config.js        # Tailwind CSS configuration
└── vercel.json               # Vercel deployment configuration
```

### Adding New Features

1. **Create Components**:
   - Add new components in the appropriate directories under `src/components/`.
   - Follow the existing component structure and styling patterns.

2. **Add Routes**:
   - Create new pages in the `src/app/` directory following the Next.js App Router conventions.

3. **Extend API Client**:
   - Add new methods to the OpenManus API client in `src/lib/api/openManus.ts`.

4. **Update Styles**:
   - Modify the Tailwind configuration in `tailwind.config.js` for global style changes.

## Customization

### Themes

The UI comes with two built-in themes:
- **Dark Mode**: Black and purple color scheme
- **Light Mode**: White and purple color scheme

To customize the themes:

1. Modify the color definitions in `tailwind.config.js`:
   ```js
   theme: {
     extend: {
       colors: {
         purple: { /* ... */ },
         dark: { /* ... */ },
         light: { /* ... */ }
       }
     }
   }
   ```

2. Update the ThemeProvider component in `src/components/ui/ThemeProvider.tsx`.

### Adding New Models

To add support for new AI models:

1. Update the `MODEL_PROVIDERS` object in `src/components/models/ModelSelector.tsx`:
   ```js
   const MODEL_PROVIDERS = {
     // Existing providers...
     new_provider: {
       name: 'New Provider',
       models: [
         { id: 'model-id', name: 'Model Name' },
         // Add more models...
       ]
     }
   }
   ```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- [OpenManus](https://github.com/mannaandpoem/OpenManus) - The open-source AI agent framework
- [Next.js](https://nextjs.org/) - The React framework
- [Tailwind CSS](https://tailwindcss.com/) - Utility-first CSS framework
- [Supabase](https://supabase.com/) - Open source Firebase alternative
